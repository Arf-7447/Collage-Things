/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_data_member;

import app_data_member.View.View_Member;

/**
 *
 * @Author ASUS TUF GAMING A15
 */
public class app_data_member {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new View_Member().setVisible(true);
    }
    
}
