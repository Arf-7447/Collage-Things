/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_data_member.Koneksi;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import java.sql.SQLException;

/**
 *
 * @Author ASUS TUF GAMING A15
 */
public class Koneksi_Member_DB {
    
    static Connection con;
    
    public static Connection connection(){
        
        if(con == null){
        MysqlDataSource data = new MysqlDataSource();
        data.setDatabaseName ("app_data_member");
        data.setUser("root");
        data.setPassword("");
        try{
            con = (Connection) data.getConnection();
        } catch (SQLException ex) {
        }
    }
    return con;
}
}
