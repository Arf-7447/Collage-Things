/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_data_member.Controller;

import javax.swing.JOptionPane;
import app_data_member.DAO.DAO_Member;
import app_data_member.DAOImplement.Implement_Member;
import app_data_member.Model.Model_Member;
import app_data_member.Model.Tabel_Model_Member;
import app_data_member.View.View_Member;

/**
 *
 * @Author @Author ASUS TUF GAMING A15
 */
public class Controller_Member {
    
    View_Member frame_member;
    Implement_Member implement_member;
    java.util.List<Model_Member> list_member;
    
    public Controller_Member(View_Member frame_member){
        this.frame_member = frame_member;
        implement_member = new DAO_Member();
        list_member = implement_member.getALL();
    }
    
    //tombol Reset
    public void reset(){
        frame_member.getTxtIDKode().setText("");
        frame_member.getTxtNamaPelanggan().setText("");
        frame_member.getTxtNoTelp().setText("");
        frame_member.getTxtAlamat().setText("");
        frame_member.getTxtPaketPelanggan().setSelectedItem("--- Pilih Paket ---");
        
    }
    
    //Tampil Data Ke Tabel 
    public void isiTable(){
        list_member = implement_member.getALL();
        Tabel_Model_Member tmb = new Tabel_Model_Member(list_member);
        frame_member.getTabelDataMember().setModel(tmb);
    }
    
    //menampilan Data ke From ketika data di klik
    public void isiField(int row){
        frame_member.getTxtIDKode().setText(list_member.get(row).getId().toString());
        frame_member.getTxtNamaPelanggan().setText(list_member.get(row).getNama());
        frame_member.getTxtNoTelp().setText(list_member.get(row).getNo_telp());
        frame_member.getTxtAlamat().setText(list_member.get(row).getAlamat());
        frame_member.getTxtPaketPelanggan().setSelectedItem(list_member.get(row).getPaket());
    }
    
    //insert Data Dari From Ke Database
    public void insert(){
        if(!frame_member.getTxtNamaPelanggan().getText().trim().isEmpty()&
            !frame_member.getTxtNoTelp().getText().trim().isEmpty()&
                !frame_member.getTxtAlamat().getText().trim().isEmpty()){
            Model_Member b = new Model_Member();
            b.setNama(frame_member.getTxtNamaPelanggan().getText());
            b.setNo_telp(frame_member.getTxtNoTelp().getText());
            b.setAlamat(frame_member.getTxtAlamat().getText());
            b.setPaket(frame_member.getTxtPaketPelanggan().getSelectedItem().toString());
            
            implement_member.insert(b);
            JOptionPane.showMessageDialog(null, "Data Berhasil di Simpan");
        } else {
            JOptionPane.showMessageDialog(frame_member, "Data Tidak Boleh Kosong");
        }
    }
    
    //Update Data Dari Table Ke Database
    public void update(){
        if(!frame_member.getTxtIDKode().getText().trim().isEmpty()){
            Model_Member b = new Model_Member();
            b.setNama(frame_member.getTxtNamaPelanggan().getText());
            b.setNo_telp(frame_member.getTxtNoTelp().getText());
            b.setAlamat(frame_member.getTxtAlamat().getText());
            b.setPaket(frame_member.getTxtPaketPelanggan().getSelectedItem().toString());
            b.setId(Integer.parseInt(frame_member.getTxtIDKode().getText()));
            
            implement_member.update(b);
            JOptionPane.showMessageDialog(null, "Data Berhail Di Update");
        } else {
            JOptionPane.showMessageDialog(frame_member, "Silahkan Pilih Data Yang Akan Di Hapus");
        }
    }
    
    //Hapus Data
    public void delete(){
        if(!frame_member.getTxtIDKode().getText().isEmpty()){
            int id = Integer.parseInt(frame_member.getTxtIDKode().getText());
            implement_member.delete(id);
            
            JOptionPane.showMessageDialog(null,"Data Berhasil DI Hapus");
        } else {
            JOptionPane.showMessageDialog(frame_member, "Silahkan Pilih Data yang Akan Di Hapus");
        }
    }
        //Cari Data
        public void isiTableCariNama(){
            list_member = implement_member.getCariNama(frame_member.getTxtCariData().getText());
            Tabel_Model_Member tmb = new Tabel_Model_Member(list_member);
            frame_member.getTabelDataMember().setModel(tmb);
        }
        
        public void carinama(){
            if(!frame_member.getTxtCariData().getText().trim().isEmpty()){
                implement_member.getCariNama(frame_member.getTxtCariData().getText());
                isiTableCariNama();
            } else {
                JOptionPane.showMessageDialog(frame_member, "Silahkan Pilih Data !!!");
            }
        }
    }

